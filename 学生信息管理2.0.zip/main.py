#1. 导入模块
from ManagerSystem import *

# 2.启动系统--
if __name__ == '__main__':
    student_manager = StudentManager()
    student_manager.run()