from student import *

class StudentManager(object):
    def __init__(self):
      self.student_list=[]

    def run(self):
    # 1.加载学员信息
        self.load_student()
        while True:
    # 2.显示功能菜单
            self.shou_menu()
    # 3.输入功能序号
            menu_num = int(input("请输入功能序号:"))
            if menu_num == 1:
                # 添加学员
                self.add_student()
            elif menu_num == 2:
                # 删除学员
                self.delete_student()
            elif menu_num == 3:
                # 修改信息
                self.change_student()
            elif menu_num == 4:
                # 查询信息
                self.search_student()
            elif menu_num == 5:
                self.show_all_student()
            elif menu_num == 6:
                self.save_student()
            elif menu_num == 7:
                # 退出系统
                break

    # 显示功能菜单
    @staticmethod
    def shou_menu():
        print("请选择以下功能")
        print("=" * 50)
        print("1.添加学员")
        print("2.删除学员")
        print("3.修改学员信息")
        print("4.查询学员信息")
        print("5.显示全部")
        print("6.保存信息")
        print("7.退出系统")
        print("=" * 50)
    # 添加学员
    def add_student(self):
        name = input("请输入你的姓名")
        gender = input("请输入你的性别")
        tel = input("请输入你的手机号")

        stu = Student(name,gender,tel)

        self.student_list.append(stu)
        print(self.student_list)
        print(stu)

    # 删除学员
    def delete_student(self):
        delete_name = input("请输入要删除的学员姓名：")

        for i in self.student_list:
            if i.name == delete_name:
                self.student_list.remove(i)
                break
        else:
            print("查无此人！")

        print(self.student_list)

    # 修改信息
    def change_student(self):
        # 用户输入目标姓名
        change_name = input("请输入要修改的学员姓名：")

        for i in self.student_list:
            if i.name == change_name:
                i.name = input("请输入学员姓名：")
                i.gender = input("请输入学员姓别：")
                i.tel = input("请输入学员电话：")
                print(f'修改该学员信息成功。姓名：{i.name},性别：{i.gender},手机号：{i.tel}')
                break
        else:
            print("查无此人！")

    # 查询信息
    def search_student(self):
        search_name = input("请输入要查询的学生姓名：")

        for i in self.student_list:
            if i.name == search_name:
                print(f'姓名：{i.name},性别：{i.gender},手机号：{i.tel}')
                break
        else:
            print("查无此人")

    # 显示全部
    def show_all_student(self):
        print('姓名\t\t性别\t\t手机号')
        for i in self.student_list:
            print(f'姓名：{i.name},性别：{i.gender},手机号：{i.tel}')

    # 保存信息
    def save_student(self):
        f = open('student,data','w')

        new_list = [i.__dict__ for i in self.student_list]

        f.write(str(new_list))
        f.close()

    # 加载信息
    def load_student(self):
        try:
            f = open('student,data','r')
        except:
            f = open('student,data','w')
        else:
            data = f.read()
            new_list = eval(data)
            self.student_list = [Student(i['name'],i['gender'],i['tel'])for i in new_list]
        finally:
            f.close()