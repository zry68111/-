import card_tools
while True:
    # TODO 显示功能菜单
    card_tools.show_menu()
    action_str=input("请选择希望执行的功能")
    print("你选择的操作是：[%s]"%action_str)

# 1,2,3针对名片的操作
    if action_str in['1','2','3']:
        # 新建名片
        if action_str=="1":
            card_tools.new_card()
        # 显示全部
        elif action_str=='2':
            card_tools.show_all()
        # 查询名片
        elif action_str=='3':
            card_tools.search_card()

        pass
# 0退出程序
    elif action_str== "0":
        print("欢迎再次使用【名片管理系统】")
        break
# 其他内容输入错误
    else:
        print("输入有误，请重新选择！")